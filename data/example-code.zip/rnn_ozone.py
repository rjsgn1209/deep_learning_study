%matplotlib inline
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from keras.layers import *
from keras.models import *
from keras.utils import *
from sklearn.preprocessing import *

pd.set_option('display.height', 1000)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)

feat = ['feat_{}'.format(i) for i in range(74)]

df = pd.read_csv('eighthr.data', names=feat)

df1 = df.apply(pd.to_numeric, errors='coerce')
df1 = df1.drop(['feat_0'], axis=1)

df1.dropna(inplace=True)

Y = df1['feat_73']
Y = to_categorical(Y)

df1.drop(['feat_73'], axis=1, inplace=True)

X_train = np.asarray(df1[:-100].values.tolist(), dtype=np.float64)
X_test = np.asarray(df1[-100:].values.tolist(), dtype=np.float64)

Y_train = Y[:-100]
Y_test = Y[-100:]

X_train = X_train[:1700]
Y_train = Y_train[:1700]

X_train = X_train.reshape(-1, 10, 72)
Y_train = Y_train.reshape(-1, 10, 2)

model = Sequential()
model.add(LSTM(128, input_shape=(10, 72,), return_sequences=True))
model.add(LSTM(256, return_sequences=True))
model.add(Dense(2, activation='softmax'))
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
model.summary()

hist = model.fit(X_train, Y_train, epochs=10, batch_size=1, validation_split=0.2)

X_test = X_test.reshape(-1, 10, 72)
Y_test = Y_test.reshape(-1, 10, 2)

score = model.evaluate(X_test, Y_test)
print(score)
'''
X = numpy.reshape(dataX, (len(dataX), 3, 1)) 
X = numpy.reshape(dataX, (len(dataX), 1, 3)) 
'''

%matplotlib inline
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from keras.layers import *
from keras.models import *
from keras.utils import *
from sklearn.preprocessing import *
import seaborn as sns

pd.set_option('display.height', 1000)
pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)

feat = ['feat_{}'.format(i) for i in range(74)]

df = pd.read_csv('eighthr.data', names=feat)

df1 = df.apply(pd.to_numeric, errors='coerce')
df1 = df1.drop(['feat_0'], axis=1)

df1.dropna(inplace=True)

Y = df1['feat_73']
Y = to_categorical(Y)

df1.drop(['feat_73'], axis=1, inplace=True)

X_train = np.asarray(df1[:-100].values.tolist(), dtype=np.float64)
X_test = np.asarray(df1[-100:].values.tolist(), dtype=np.float64)

Y_train = Y[:-100]
Y_test = Y[-100:]

model = Sequential()
model.add(Dense(256, input_shape=(72,), activation='tanh'))
model.add(Dense(256, activation='tanh'))
model.add(Dense(2, activation='softmax'))
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
model.summary()

hist = model.fit(X_train, Y_train, epochs=10, batch_size=50, validation_split=0.2)

score = model.evaluate(X_test, Y_test)
print(score)