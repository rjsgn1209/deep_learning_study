
%matplotlib inline
import matplotlib.pyplot as plt
import numpy as np
from keras.layers import Dense, Input
from keras.models import Model, Sequential
from keras.utils import to_categorical
from collections import Counter

import pandas as pd
from sklearn.preprocessing import MinMaxScaler

'''
age: continuous. 
workclass: Private, Self-emp-not-inc, Self-emp-inc, Federal-gov, Local-gov, State-gov, Without-pay, Never-worked. 
fnlwgt: continuous. 
education: Bachelors, Some-college, 11th, HS-grad, Prof-school, Assoc-acdm, Assoc-voc, 9th, 7th-8th, 12th, Masters, 1st-4th, 10th, Doctorate, 5th-6th, Preschool. 
education-num: continuous. 
marital-status: Married-civ-spouse, Divorced, Never-married, Separated, Widowed, Married-spouse-absent, Married-AF-spouse. 
occupation: Tech-support, Craft-repair, Other-service, Sales, Exec-managerial, Prof-specialty, Handlers-cleaners, Machine-op-inspct, Adm-clerical, Farming-fishing, Transport-moving, Priv-house-serv, Protective-serv, Armed-Forces. 
relationship: Wife, Own-child, Husband, Not-in-family, Other-relative, Unmarried. 
race: White, Asian-Pac-Islander, Amer-Indian-Eskimo, Other, Black. 
sex: Female, Male. 
capital-gain: continuous. 
capital-loss: continuous. 
hours-per-week: continuous. 
native-country: United-States, Cambodia, England, Puerto-Rico, Canada, Germany, Outlying-US(Guam-USVI-etc), India, Japan, Greece, South, China, Cuba, Iran, Honduras, Philippines, Italy, Poland, Jamaica, Vietnam, Mexico, Portugal, Ireland, France, Dominican-Republic, Laos, Ecuador, Taiwan, Haiti, Columbia, Hungary, Guatemala, Nicaragua, Scotland, Thailand, Yugoslavia, El-Salvador, Trinadad&Tobago, Peru, Hong, Holand-Netherlands.
'''


df = pd.read_csv('adult.data', index_col=False, names=['a', 'w', 'f', 'e', 'ed', 'm', 'o', 'r', 'ra', 's', 'c', 'ca', 'h', 'n', '5k'])
df.head()

sns.countplot('5k',data=df)
sns.countplot('5k',hue='s',data=df)
sns.heatmap(df.corr(),annot=True, cmap='summer_r', linewidths=0.2)
sns.violinplot("ra","a", hue="5k", data=df, split=True)

Y = df['5k'].values.tolist()
Y = [0 if i == ' <=50K' else 1 for i in Y]
Y = to_categorical(Y)

X = df.drop(['a', 'f', 'ed', 'c', 'ca', 'h'], axis=1)
X = pd.get_dummies(X, drop_first=True)
X = pd.concat([X, df[['a', 'f', 'ed', 'c', 'ca', 'h']]], axis=1)

scaler = MinMaxScaler()
X[['a', 'f', 'ed', 'c', 'ca', 'h']] = scaler.fit_transform(X[['a', 'f', 'ed', 'c', 'ca', 'h']])

model = Sequential()
model.add(Dense(2048, input_shape=(101,), activation='relu'))
model.add(Dense(512, activation='relu'))
model.add(Dense(256, activation='relu'))
model.add(Dense(128, activation='relu'))
model.add(Dense(2, activation='softmax'))

model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

model.summary()

model.fit(X, Y, epochs=1)

plt.figure(figsize=(10,10))
plt.subplot(1, 2, 1)
plt.plot(hist.history['acc'], color='r')
plt.plot(hist.history['val_acc'], color='b')
plt.title('acc')
plt.subplot(1, 2, 2)
plt.plot(hist.history['loss'], color='r')
plt.plot(hist.history['val_loss'], color='b')
plt.title('loss')
plt.show()









