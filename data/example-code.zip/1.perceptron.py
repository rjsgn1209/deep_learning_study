%matplotlib inline
import matplotlib.pyplot as plt
import numpy as np
from keras.layers import Dense, Input
from keras.models import Model, Sequential
from keras.utils import to_categorical
from collections import Counter

x = np.linspace(1,10, 1000)
y = 2 * x + 1

plt.plot(x, y)

model = Sequential()
model.add(Dense(1, activation ='linear', input_shape=(1,)))
model.summary()

model.compile(loss = 'mse', optimizer='sgd')
hist = model.fit(x, y, epochs=30)

print(hist)
print(model.get_weights())

pred_x = []
pred_x = np.append(pred_x, 12)
pred_x = np.append(pred_x, 14)

pred_y = model.predict(pred_x)
print(pred_y)

plt.scatter(pred_x, pred_y)
