%matplotlib inline
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from keras.layers import *
from keras.models import *
from keras.utils import *
from sklearn.preprocessing import *
import seaborn as sns

pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)


X_train = pd.read_csv('dataset_uci/final_X_train.txt', names=label)
X_test = pd.read_csv('dataset_uci/final_X_test.txt', names=label)

Y_train = pd.read_csv('dataset_uci/final_Y_train.txt', names='Y')
Y_test = pd.read_csv('dataset_uci/final_Y_test.txt', names='Y')

Y_train = to_categorical(Y_train)
Y_test = to_categorical(Y_test)
Y_train = Y_train[:,1:]
Y_test = Y_test[:,1:]

label = ['feat_{}'.format(i) for i in range(561)]

X_train = np.asarray(X_train.values.tolist())
X_test = np.asarray(X_test.values.tolist())

X_train = X_train.reshape(-1, 1, 561)
X_test = X_test.reshape(-1, 1, 561)

model = Sequential()
model.add(Bidirectional(LSTM(128, return_sequences=True), input_shape=(1, 561)))
model.add(Activation('relu'))
model.add(Bidirectional(LSTM(256, return_sequences=True)))
model.add(Activation('relu'))
model.add(Dropout(0.2))
model.add(LSTM(512))
model.add(Dropout(0.2))
model.add(Dense(6, activation='softmax'))
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
model.summary()

model.fit(X_train, Y_train, epochs=10, validation_split=0.2, batch_size=100)

