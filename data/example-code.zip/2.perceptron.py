%matplotlib inline
import matplotlib.pyplot as plt
import numpy as np
from keras.layers import Dense, Input
from keras.models import Model, Sequential
from keras.utils import to_categorical
from collections import Counter

num_samples = 500

x = np.array([
    np.random.uniform(-np.pi, np.pi, num_samples),
    np.random.uniform(-1, 1, num_samples)
]).T

#plt.scatter(x[:,0], x[:,1])
plt.scatter(x[:,0], np.sin(x[:,0]))
# print(x)

# plt.scatter(x[:,0], x[:,1])

y = (np.sin(x[:,0]) < x[:,1]).astype(np.float32) 
print(Counter(y))

plt.scatter(x[:,0][y==1], x[:,1][y==1])
plt.scatter(x[:,0][y==0], x[:,1][y==0])


model = Sequential()
model.add(Dense(10, activation ='relu', input_shape=(2,)))
model.add(Dense(10, activation='relu'))
model.add(Dense(10, activation='relu'))
model.add(Dense(10, activation='relu'))
model.add(Dense(2, activation='softmax'))
# model.summary()

Y = to_categorical(y)

model.compile(loss = 'mse', optimizer='sgd', metrics=['accuracy'])
model.fit(x, Y, epochs=200, verbose=0)
print(hist)


a = np.array([-2,0])
b = np.array([1,0])
pred_x = np.vstack((a, b))
print(pred_x)

pred_y = model.predict(pred_x)

print(pred_y)
