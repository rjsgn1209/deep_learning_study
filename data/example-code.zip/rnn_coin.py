%matplotlib inline
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import plotly as py
import plotly.graph_objs as go
import requests
from keras.layers import *
from keras.models import *
from keras.callbacks import *
from datetime import datetime
from sklearn.preprocessing import MinMaxScaler
plt.style.use('bmh')

# https://poloniex.com/public?command=returnChartData&currencyPair=USDT_BTC&start=1405699200&end=9999999999&period=14400


ret = requests.get('https://poloniex.com/public?command=returnChartData&currencyPair=USDT_BTC&start=1405699200&end=9999999999&period=86400')

js = ret.json()

df = pd.DataFrame(js)
df['strdate'] = df['date'].apply(lambda x: datetime.fromtimestamp(x).strftime('%Y-%m-%d %H:%M:%S'))

df
scaler = MinMaxScaler()
df[['close']] = scaler.fit_transform(df[['close']])
price = df['close'].values.tolist()
window_size = 5
X = []
Y = []

for i in range(len(price)-window_size):
    X.append([price[i+j] for j in range(window_size)])

for i in range(len(price)-window_size):
    Y.append(price[window_size + i])


X = np.asarray(X)
Y = np.asarray(Y)

train_test_split = 1000
# partition the training set
X_train = X[:train_test_split,:]
Y_train = Y[:train_test_split]

# keep the last chunk for testing
X_test = X[train_test_split:,:]
Y_test = Y[train_test_split:]

# NOTE: to use keras's RNN LSTM module our input must be reshaped to [samples, window size, stepsize] 
X_train = np.asarray(np.reshape(X_train, (X_train.shape[0], window_size, 1)))
X_test = np.asarray(np.reshape(X_test, (X_test.shape[0], window_size, 1)))

X_train.shape


model = Sequential()
model.add(LSTM(128, input_shape=(5, 1)))
model.add(Dropout(0.2))
model.add(Dense(1, activation='linear'))
model.compile(loss='mean_squared_error', optimizer='adam')
model.summary()

model.fit(x=X_train, y=Y_train, epochs=100, batch_size=1, verbose=1)
mode = load_model('coin.h5')

train_predict = model.predict(X_train)
test_predict = model.predict(X_test)

### Plot everything - the original series as well as predictions on training and testing sets
import matplotlib.pyplot as plt
%matplotlib inline

plt.figure(figsize=(10,10))

plt.plot(price)

# plot training set prediction
split_pt = train_test_split + window_size 

plt.plot(np.arange(window_size,split_pt,1),train_predict,color = 'b')

# plot testing set prediction
plt.plot(np.arange(split_pt,split_pt + len(test_predict),1),test_predict,color = 'r')

# pretty up graph
plt.xlabel('day')
plt.ylabel('(normalized) price of bitcoin stock')
plt.legend(['original series','training fit','testing fit'],loc='center left', bbox_to_anchor=(1, 0.5))
plt.show()

trace = go.Scatter(x=np.arange(1,len(price),1), y=price, mode = 'lines', name='original')
trace2 = go.Scatter(x=np.arange(window_size,split_pt,1), y=train_predict.reshape(1000), mode = 'lines', name='train')
trace3 = go.Scatter(x=np.arange(split_pt,split_pt + len(test_predict),1), y=test_predict.reshape(85), mode = 'lines', name='pred')

data = [trace, trace2, trace3]
py.offline.plot(data)
