path = "lastofus.txt"

text = ''
with open(path) as f:
    lines = f.readlines()
    
    text = text.join([l for l in lines if re.match(r'^[A-Z].*:', l)])

k = []
for t in text.split('\n')[:1000]:
    k.append(t)

token = Tokenizer(lower=False, filters='.,?;\'\"-')

token.fit_on_texts(k)

train_seq = token.texts_to_sequences(k)
train_mat = token.texts_to_matrix(k)

train_seq = pad_sequences(train_seq, maxlen=10)

X = train_seq
Y = np.vstack((X[1:], X[0]))

X = X.reshape(-1, 10, 1)
Y = Y.reshape(-1, 10, 1)

Y = to_categorical(Y)
Y.shape

model = Sequential()
model.add(Bidirectional(SimpleRNN(128, return_sequences=True), input_shape=(10, 1)))
model.add(Bidirectional(SimpleRNN(128, return_sequences=True)))
model.add(Dense(1385))
model.add(Activation('softmax'))

model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
model = load_model('model.save')

idx_word = {}
for w in token.word_index:
    idx_word[token.word_index[w]] = w

for i in range(10):
    temp = ''
    ran = random.randrange(0, len(X))
    pred = model.predict(np.expand_dims(X[ran], axis=0))
    pred = np.argmax(pred, axis=2)

    for line in pred:
        for word in line:        
            if word != 0:            
                temp += idx_word[word]
                temp += ' '
        temp += '\n'
    print(k[ran])
    print(temp)


    